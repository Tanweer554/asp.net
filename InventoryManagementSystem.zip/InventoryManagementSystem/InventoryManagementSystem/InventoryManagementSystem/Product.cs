﻿using System;
using System.Collections.Generic;
using System.Text;
namespace InventoryManagementSystem
{
    public class Product
    {
        
        string ConnectionString = "Data Source=.;Initial Catalog=ProductsDB;User ID=sa;Password=wipro@123";

        public bool ADDProduct(Product obj)
        {            
            throw new NotImplementedException();
        }


        public bool ModifyProduct(Product obj)
        {
            throw new NotImplementedException();
        }

        public bool DeleteProduct(int productID)
        {
            throw new NotImplementedException();
        }


        public Product ViewProduct(int productID)
        {
            throw new NotImplementedException();
        }


        public List<Product> ViewAllProducts()
        {
            throw new NotImplementedException();
        }
    }
}
