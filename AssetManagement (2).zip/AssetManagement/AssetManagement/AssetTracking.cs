﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetManagement
{
    public class AssetTracking
    {
        const string ConnectionString = "Data Source=.;Initial Catalog=AssetManagement;User ID=sa;Password=wipro@123";
        public bool AddAsset(Asset obj)
        {
           bool Isadded = false;
            //throw new NotImplementedException();
            if (obj != null)
            {
                string s = null;
                Random rand = new Random();
                int i = rand.Next(1, 1000);

                s += obj.AssetType[0] + obj.AssetType[1] + i.ToString();
                obj.SerialNo = s;

                SqlConnection con = new SqlConnection(ConnectionString);
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "insert into Asset values(@at,@sn,@pd,@ts)";
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("@at", obj.AssetType);
                cmd.Parameters.AddWithValue("@sn", obj.SerialNo);
                cmd.Parameters.AddWithValue("@pd", DateTime.Now);
                cmd.Parameters.AddWithValue("@ts", "FREE POOL");
                con.Open();
                int rowcount = cmd.ExecuteNonQuery();
                con.Close();
                if (rowcount == 1)
                {
                    Isadded = true;
                }
                else
                {
                    Isadded = false;
                }
            }
            else
            {
                Isadded = false;
            }
            return Isadded;
        }

        public bool ModifyAsset(Asset obj)
        {
            bool Ismodify = false;
            //  throw new NotImplementedException();
            if (obj != null)
            {
                SqlConnection con = new SqlConnection(ConnectionString);
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "update Asset set SerialNo=@sn,AssetType=@at,ProcurementDate=@pd where AssetID=@aid";
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("@sn", obj.SerialNo);
                cmd.Parameters.AddWithValue("@at", obj.AssetType);
                cmd.Parameters.AddWithValue("@pd", DateTime.Now);
                cmd.Parameters.AddWithValue("@aid", obj.AssetID);
                con.Open();
                int rowcount = cmd.ExecuteNonQuery();
                con.Close();
                if (rowcount == 1)
                {
                    Ismodify = true;
                }
                else
                {
                    Ismodify = false;
                }
            }
            else
            {
                Ismodify = false;
            }
            return Ismodify;
        }

        public bool TagAsset(AssetTagging obj)
        {
            throw new NotImplementedException();
        }

        public bool DeTagAsset(int intAssetId)
        {
            throw new NotImplementedException();
        }
    }
}
