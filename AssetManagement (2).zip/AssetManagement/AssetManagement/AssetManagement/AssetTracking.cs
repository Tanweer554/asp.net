﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetManagement
{
    public class AssetTracking
    {
        const string ConnectionString = "Data Source=.;Initial Catalog=AssetManagement;User ID=sa;Password=wipro@123";
        public bool AddAsset(Asset obj)
        {
            throw new NotImplementedException();
        }

        public bool ModifyAsset(Asset obj)
        {
            throw new NotImplementedException();
        }

        public bool TagAsset(AssetTagging obj)
        {
            throw new NotImplementedException();
        }

        public bool DeTagAsset(int intAssetId)
        {
            throw new NotImplementedException();
        }
    }
}
