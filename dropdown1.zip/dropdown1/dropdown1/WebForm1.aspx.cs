﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace dropdown1
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack) {
                DropDownList1.Items.Clear();
                DropDownList1.Items.Add("--select--");
                DropDownList2.Items.Clear();
                DropDownList2.Items.Add("--select--");
                DropDownList3.Items.Clear();
                DropDownList3.Items.Add("--select--");
                SqlConnection con = new SqlConnection("server=.;Initial Catalog=demodb;User id=sa;password=wipro@123");
                SqlCommand cmd = new SqlCommand("select * from country", con);
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                DropDownList1.DataSource = dr;
                DropDownList1.DataTextField = "countryname";
                DropDownList1.DataValueField = "countryid";
                DropDownList1.DataBind();
                con.Close();
                }
        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
           
            DropDownList2.Items.Clear();
            DropDownList2.Items.Add("--select--");

            DropDownList3.Items.Clear();
            DropDownList3.Items.Add("--select--");
            SqlConnection con = new SqlConnection("server=.;Initial Catalog=demodb;User id=sa;password=wipro@123");
            SqlCommand cmd = new SqlCommand("select * from state1 where countryid=@cid", con);
            cmd.Parameters.AddWithValue("@cid", DropDownList1.SelectedValue);
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            DropDownList2.DataSource = dr;
            DropDownList2.DataTextField = "statename";
            DropDownList2.DataValueField = "stateid";
            DropDownList2.DataBind();
            con.Close();

        }

        protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
        {
            DropDownList3.Items.Clear();
            DropDownList3.Items.Add("--select--");
            SqlConnection con = new SqlConnection("server=.;Initial Catalog=demodb;User id=sa;password=wipro@123");
            SqlCommand cmd = new SqlCommand("select * from city1 where stateid=@sid", con);
            cmd.Parameters.AddWithValue("@sid", DropDownList2.SelectedValue);
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            DropDownList3.DataSource = dr;
            DropDownList3.DataTextField = "cityname";
            DropDownList3.DataValueField = "cityid";
            DropDownList3.DataBind();
            con.Close();


        }
    }
}