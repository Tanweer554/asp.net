﻿using System;
using System.Data.SqlClient;

namespace MovieTicketing
{
    public class TicketingDataAccess
    {
        string ConnectionString = "Data Source=.;Initial Catalog=MovieTicketing;User ID=sa;Password=wipro@123";

        public bool AddMovie(Movies obj)
        {
            // throw new NotImplementedException();
            bool IsAdded = false;
            if (obj != null)
            {
                SqlConnection con = new SqlConnection(ConnectionString);
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "Insert into Movies(MovieName,Director,PlaysPerDay,TicketPrice) Values(@mn,@dir,@ppd,@tp)";
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("@mn", obj.MovieName);
                cmd.Parameters.AddWithValue("@dir", obj.DirectorName);
                cmd.Parameters.AddWithValue("@ppd", obj.PlaysPerDay);
                cmd.Parameters.AddWithValue("@tp", obj.TicketPrice);
                con.Open();

                int rowcount = cmd.ExecuteNonQuery();
                con.Close();
                if (rowcount == 1)
                {
                    IsAdded = true;
                }
                else
                {
                    IsAdded = false;
                }
            }
            return IsAdded;
        }

        public bool AddTheatre(Theatres obj)
        {
            // throw new NotImplementedException();
           bool IsAdded = false;
            if (obj != null)
            {
                SqlConnection con = new SqlConnection(ConnectionString);
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "Insert into Theatres(TheatreName,SeatingCapacity) Values(@tn,@sc)";
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("@tn", obj.TheatreName);
                cmd.Parameters.AddWithValue("@sc", obj.SeatingCapacity);
                con.Open();
                int rowcount=cmd.ExecuteNonQuery();
                con.Close();
                if (rowcount == 1)
                {
                    IsAdded = true;
                }
                else
                {
                    IsAdded = false;
                }


            }
            return IsAdded;
        }

        public bool AddShow(Shows obj)
        {
            bool IsAdded = false;
            if (obj != null)
            {
                SqlConnection con = new SqlConnection(ConnectionString);
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "Insert into Shows(TheatreID,MovieID,StartDate,EndDate,StartTime,EndTime) Values(@tid,@mid,@sd,@ed,@st,@et)";
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("@tid", obj.TheatreID);
                cmd.Parameters.AddWithValue("@mid", obj.MovieID);
                cmd.Parameters.AddWithValue("@sd", obj.StartDate);
                cmd.Parameters.AddWithValue("@ed", obj.EndDate);
                cmd.Parameters.AddWithValue("@st", obj.StartTime);
                cmd.Parameters.AddWithValue("@et", obj.EndTime);
                con.Open();
         
                int rowcount = cmd.ExecuteNonQuery();
                con.Close();
                if (rowcount == 1)
                {
                    IsAdded = true;
                }
                else
                {
                    IsAdded = false;
                }


            }
            return IsAdded;
        }

        public string AddTicket(Tickets obj)
        {
            string moviename = "";
            decimal ticketprice = 0 ;
            string refcode = null ;
            if (obj != null)
            {
                SqlConnection con = new SqlConnection(ConnectionString);
                string query = "Select m.MovieName, m.TicketPrice from Movies m JOIN Shows s ON m.MovieID=s.MovieID JOIN Tickets t ON s.ShowID=t.ShowID where t.ShowID=@sid";
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = query;
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("@sid", obj.ShowID);
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
              
                if (dr.HasRows)
                {
                    dr.Read();
                    moviename = dr["MovieName"].ToString();
                    ticketprice = decimal.Parse(dr["TicketPrice"].ToString());
                }
                con.Close();
                refcode += obj.CustomerName[0] + obj.CustomerName[1] + obj.NumberofPersons +moviename[0]+moviename[1]+ obj.BookingDate.Day.ToString() + obj.BookingDate.Month.ToString();
                Random rand = new Random();
                rand.Next(1, 1000);
                refcode += rand.ToString();
                refcode += refcode.ToUpper();        
            }
            return refcode;
        }


        public int DeleteMovie(int intMovieID)
        {
            //  throw new NotImplementedException();
            int deletedrows = 0;
            SqlConnection con = new SqlConnection(ConnectionString);
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "select ShowID from Shows where MovieID=@mid";
            cmd.Connection = con;
            cmd.Parameters.AddWithValue("@mid", intMovieID);
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();

            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    int showid = int.Parse(dr["ShowID"].ToString());
                    SqlConnection con1 = new SqlConnection(ConnectionString);
                    SqlCommand cmd1 = new SqlCommand();
                    cmd1.CommandText = "delete from Tickets where ShowID=@sid";
                    cmd1.Connection = con1;
                    cmd1.Parameters.AddWithValue("@sid", showid);
                    con1.Open();
                    int rows = cmd1.ExecuteNonQuery();
                    deletedrows += rows;
                    con1.Close();
                }
            }
            con.Close();

            SqlCommand cmd2 = new SqlCommand();
            cmd2.CommandText = "delete from Shows where MovieID=@mid";
            cmd2.Connection = con;
            cmd2.Parameters.AddWithValue("@mid", intMovieID);
            con.Open();
            int newrows = cmd2.ExecuteNonQuery();
            con.Close();
            deletedrows += newrows;

            SqlCommand cmd3 = new SqlCommand();
            cmd3.CommandText = "delete from Movies where MovieID=@mid";
            cmd3.Connection = con;
            cmd3.Parameters.AddWithValue("@mid", intMovieID);
            con.Open();
            int newrows2 = cmd3.ExecuteNonQuery();
            con.Close();
            deletedrows += newrows2;
            if (deletedrows == 0)
            {
                return 0;
            }
            else
            {
                return deletedrows;
            }
        }
                
    }
}
