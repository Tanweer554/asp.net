﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {

            String input1 = "12B3A4NGALORE";
              
                int num_count = 0, sum_num = 0;
                int alp_count = 0, j = 0;
                
                char[] carrnew = new char[20];
                char[] carr = input1.ToCharArray();
                Console.WriteLine(carr);
                for (int i = 0; i < carr.Length; i++)
                {
                    if (char.IsDigit(carr[i]))
                    {
                        num_count++;
                        int a = (int)Char.GetNumericValue(carr[i]);
                        sum_num += a;
                    }
                    else if (char.IsLetter(carr[i]))
                    {
                        alp_count++;
                        carrnew[j++] = carr[i];

                    }

                }
                Console.WriteLine("num_count:{0}", num_count);
                Console.WriteLine("alp_count:{0}", alp_count);
                Console.WriteLine("sum_num:{0}", sum_num);

                if (num_count == 0)
                {
                Console.WriteLine("ZERO");
            }
                if (alp_count == 0)
                {
                    Console.WriteLine("ZERO");
            }
                if (sum_num == 0)
                {
                Console.WriteLine("ZERO");
            }
                string alpha = new string(carrnew);
                Console.WriteLine("alpha:{0}", alpha);
                string result = alp_count.ToString() + alpha + sum_num.ToString();
                Console.WriteLine("result:{0}", result);
               

            }
        }


    }
