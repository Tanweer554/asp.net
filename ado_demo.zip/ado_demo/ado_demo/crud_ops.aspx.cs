﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace ado_demo
{
    public partial class crud_ops : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Server=.;Initial Catalog=demodb;User ID=sa;Password=wipro@123";
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "select * from employee";
            cmd.Connection = con;
            con.Open();
            SqlDataReader dr=cmd.ExecuteReader();
            GridView1.DataSource = dr;
            GridView1.DataBind();
            con.Close();

        }

        protected void btninsert_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Server=.;Initial Catalog=demodb;User ID=sa;Password=wipro@123";
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "Insert into employee(empname,age,[address],did) values(@en,@age,@address,@did)";
            cmd.Parameters.AddWithValue("@en", txtname.Text);
            cmd.Parameters.AddWithValue("@age", txtage.Text);
            cmd.Parameters.AddWithValue("@address", txtaddress.Text);
            cmd.Parameters.AddWithValue("@did", txtdid.Text);
            cmd.Connection = con;
            con.Open();
            int rowcount = cmd.ExecuteNonQuery();
            con.Close();
            if (rowcount == 1)
            {
                Response.Write("Record Inserted");
            }
        }

        protected void btndelete_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Server=.;Initial Catalog=demodb;User ID=sa;Password=wipro@123";
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "delete from employee where empid=@eid";
            cmd.Parameters.AddWithValue("@eid", txtid.Text);
          
            cmd.Connection = con;
            con.Open();
            int rowcount = cmd.ExecuteNonQuery();
            con.Close();
            if (rowcount == 1)
            {
                Response.Write("Record Deleted");
            }
        }

        protected void btnupdate_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Server=.;Initial Catalog=demodb;User ID=sa;Password=wipro@123";
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "update employee set  empname=@en,Age=@age,address=@address, did=@did where empid=@eid";
            cmd.Parameters.AddWithValue("@eid", txtid.Text);
            cmd.Parameters.AddWithValue("@en", txtname.Text);
            cmd.Parameters.AddWithValue("@age", txtage.Text);
            cmd.Parameters.AddWithValue("@address", txtaddress.Text);
            cmd.Parameters.AddWithValue("@did", txtdid.Text);

            cmd.Connection = con;
            con.Open();
            int rowcount = cmd.ExecuteNonQuery();
            con.Close();
            if (rowcount == 1)
            {
                Response.Write("Record Updated");
            }
        }

        protected void btnsearch_Click(object sender, EventArgs e)
        {

            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Server=.;Initial Catalog=demodb;User ID=sa;Password=wipro@123";
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "select * from employee where empid=@id";
       
            cmd.Parameters.AddWithValue("@id", txtid.Text);

            cmd.Connection = con;
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                dr.Read();
               
                txtname.Text = dr["empname"].ToString();
                txtage.Text = dr["age"].ToString();
                txtaddress.Text = dr["address"].ToString();
                txtdid.Text = dr["did"].ToString();


            }
            else
            {
                Response.Write("No records found");
            }
            con.Close();
      
        }
    }
}