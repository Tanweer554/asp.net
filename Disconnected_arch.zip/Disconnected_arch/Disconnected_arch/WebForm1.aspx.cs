﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace Disconnected_arch
{
    public partial class WebForm1 : System.Web.UI.Page
    {
         public DataTable GetAllEmployees()
        {
            SqlConnection con = new SqlConnection("server=.;Initial Catalog=DemoDB;User Id=sa;Password=wipro@123;");
            SqlDataAdapter da = new SqlDataAdapter("select * from Employee",con);
            da.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            DataSet ds = new DataSet();
            da.Fill(ds, "Employee");
            return ds.Tables["Employee"];
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack) {
            DataTable dt = GetAllEmployees();
            ViewState["empdata"] = dt;
            GridView1.DataSource = dt;
            GridView1.DataBind();
           }
        }

    protected void btninsert_Click(object sender, EventArgs e)
    {
            DataTable dt = (DataTable)ViewState["empdata"];
            DataRow dr = dt.NewRow();
            dr["EmpName"] = txtname.Text;
            dr["Age"] = txtage.Text;
            dr["Address"] = txtaddress.Text;
            dr["did"] = txtdid.Text;
            dt.Rows.Add(dr);
            ViewState["empdata"] = dt;
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }
    

        protected void btnupdate_Click(object sender, EventArgs e)
        {
            DataTable dt = (DataTable)ViewState["empdata"];
            DataRow dr = dt.Rows.Find(int.Parse(txtid.Text));
            dr["EmpName"] = txtname.Text;
            dr["Age"] = txtage.Text;
            dr["Address"] = txtaddress.Text;
            dr["did"] = txtdid.Text;
            ViewState["empdata"] = dt;
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }

        protected void btndelete_Click(object sender, EventArgs e)
        {

            DataTable dt = (DataTable)ViewState["empdata"];
            DataRow dr = dt.Rows.Find(int.Parse(txtid.Text));
            dr.Delete();
            ViewState["empdata"] = dt;
            GridView1.DataSource = dt;
            GridView1.DataBind();

        }

        protected void Btnsavechanges_Click(object sender, EventArgs e)
        {
            DataTable dt = (DataTable)ViewState["empdata"];
            SqlConnection con = new SqlConnection("server=.;Initial Catalog=DemoDB;User Id=sa;Password=wipro@123;");
            SqlDataAdapter da = new SqlDataAdapter("select * from Employee", con);
            da.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            SqlCommandBuilder cmdbldr = new SqlCommandBuilder(da);
            da.Update(dt);

        }
    }
}