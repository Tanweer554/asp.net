﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Text;
namespace InventoryManagementSystem
{
    public class Product
    {
        public int ProductID { get; set; }
        public string ProductName { get; set; }
        public string Description { get; set; }
        public int Quantity { get; set; }
        public int UnitPrice { get; set; }


        string ConnectionString = "Data Source=.;Initial Catalog=ProductsDB;User ID=sa;Password=wipro@123";

        public bool ADDProduct(Product obj)
        {
            bool Isadded = false;
            // throw new NotImplementedException();
            SqlConnection con = new SqlConnection(ConnectionString);
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "Insert into Products(PRODUCTNAME,DESCRIPTION,AVAILABLEQUANTITY,UNITPRICE) values(@pn,@des,@avail,@up)";
            cmd.Connection = con;
            cmd.Parameters.AddWithValue("@pn", obj.ProductName);
            cmd.Parameters.AddWithValue("@des", obj.Description);
            cmd.Parameters.AddWithValue("@avail", obj.Quantity);
            cmd.Parameters.AddWithValue("@up", obj.UnitPrice);
            con.Open();
            int rows = cmd.ExecuteNonQuery();
            con.Close();
            if (rows==1)
            {
                Isadded = true;
            }
            return Isadded;
        }


        public bool ModifyProduct(Product obj)
        {
            //throw new NotImplementedException();
            bool Ismodify = false;
            // throw new NotImplementedException();
            SqlConnection con = new SqlConnection(ConnectionString);
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "update Products set PRODUCTNAME=@pn,DESCRIPTION=@des,AVAILABLEQUANTITY=@avail,UNITPRICE=@up where PRODUCTID=@pid ";
            cmd.Connection = con;
            cmd.Parameters.AddWithValue("@pid", obj.ProductID);
            cmd.Parameters.AddWithValue("@pn", obj.ProductName);
            cmd.Parameters.AddWithValue("@des", obj.Description);
            cmd.Parameters.AddWithValue("@avail", obj.Quantity);
            cmd.Parameters.AddWithValue("@up", obj.UnitPrice);
            con.Open();
            int rows = cmd.ExecuteNonQuery();
            con.Close();
            if (rows == 1)
            {
                Ismodify = true;
            }
            return Ismodify;
        }

        public bool DeleteProduct(int productID)
        {
            // throw new NotImplementedException();
            bool Isdeleted = false;
            // throw new NotImplementedException();
            SqlConnection con = new SqlConnection(ConnectionString);
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "delete from Products where PRODUCTID=@pid";
            cmd.Connection = con;
            cmd.Parameters.AddWithValue("@pid",productID);  
            con.Open();
            int rows = cmd.ExecuteNonQuery();
            con.Close();
            if (rows == 1)
            {
                Isdeleted = true;
            }
            return Isdeleted;
        }


        public Product ViewProduct(int productID)
        {
            //throw new NotImplementedException();
          
                
                SqlConnection con = new SqlConnection(ConnectionString);
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "select PRODUCTNAME,DESCRIPTION,AVAILABLEQUANTITY,UNITPRICE from Products where PRODUCTID=@pid";
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("@pid", productID);
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
               
                if (dr.HasRows)
                {
                    dr.Read();
                    Product p = new Product();
                    p.ProductName = dr["PRODUCTNAME"].ToString();
                    p.Description = dr["DESCRIPTION"].ToString();
                    p.Quantity = int.Parse(dr["AVAILABLEQUANTITY"].ToString());
                    p.UnitPrice = int.Parse(dr["UNITPRICE"].ToString());
                return p;
                }
                con.Close();
            return null;
        }
        
           
    


        public List<Product> ViewAllProducts()
        {
            // throw new NotImplementedException();
            List<Product> viewdetails = new List<Product>();
            Product p = new Product();
            SqlConnection con = new SqlConnection(ConnectionString);
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "select * from Products";
            cmd.Connection = con;
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    p.ProductName = dr["PRODUCTNAME"].ToString();
                    p.Description = dr["DESCRIPTION"].ToString();
                    p.Quantity = int.Parse(dr["AVAILABLEQUANTITY"].ToString());
                    p.UnitPrice = int.Parse(dr["UNITPRICE"].ToString());
                }
             con.Close();
                viewdetails.Add(p);
            }
            return viewdetails;
        }
    }
}
