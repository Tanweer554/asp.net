﻿using System;
using System.Collections.Generic;

//Read only region start
public class UserMainCode
{
    //Assume following return types while writing the code for this question. 
    public class Result
    {
        public int output1;
        public int output2;
    }

    public Result findOriginalFirstAndSum(int[] input1, int input2)
    {
        //Read only region end
        //Write code here
        int first = input1[input2 - 1];
        int sum = input1[input2 - 1];
        for (int i = input2 - 2; i >= 0; i--)
        {
            first = input1[i] - first;
            sum = sum + first;
        }
        Result r = new Result();
        r.output1 = first;
        r.output2 = sum;
        return r;
    }
}