﻿using System;
using System.Collections.Generic;

//Read only region start
public class UserMainCode
{
    public int sumOfPowerOfDigits(int input1)
    {
        //Read only region end
        //Write code here
        int[] intarr = new int[10];
        int i = 0;
        int sum = 1;
        while (input1 > 0)
        {
            intarr[i] = input1 % 10;
            input1 /= 10;
            i++;
        }
        for (int j = i; j > 0; j--)
        {
            sum = sum + (int)Math.Pow(intarr[j], intarr[j - 1]);
        }
        return sum;
    }
}