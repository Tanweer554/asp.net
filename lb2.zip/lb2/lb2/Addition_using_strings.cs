﻿using System;
using System.Collections.Generic;

//Read only region start
public class UserMainCode
{
    public string addNumberStrings(string input1, string input2)
    {
        //Read only region end
        //Write code here
        decimal d1 = decimal.Parse(input1);
        decimal d2 = decimal.Parse(input2);
        return (d1 + d2).ToString();
    }
}