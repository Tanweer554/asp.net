﻿using System;
using System.Collections.Generic;

//Read only region start
public class UserMainCode
{
    public int getCodeThroughStrings(string input1)
    {
        //Read only region end
        //Write code here
        string[] strarr1 = input1.Split(' ');
        int sum = 0;
        int rsum = 0;
        for (int i = 0; i < strarr1.Length; i++)
        {
            sum = sum + strarr1[i].Length;
        }

        if (sum > 9)
        {
            int a = sum % 10;
            sum = sum / 10;
            rsum = sum + a;
        }
        return rsum;
    }
}