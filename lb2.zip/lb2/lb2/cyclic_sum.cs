﻿using System;
using System.Collections.Generic;

//Read only region start
public class UserMainCode
{
    public int sumOfSumsOfDigits(int input1)
    {
        //Read only region end
        //Write code here
        int[] intarr = new int[input1.ToString().Length];
        int i = 0, p = 1, sum = 0;
        while (input1 > 0)
        {
            intarr[i] = input1 % 10;
            input1 /= 10;
            i++;
        }
        Array.Reverse(intarr);
        for (int j = 0; j < intarr.Length; j++)
        {
            sum += intarr[j] * p;
            p++;
        }
        return sum;
    }
}