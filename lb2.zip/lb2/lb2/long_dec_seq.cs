﻿using System;
using System.Collections.Generic;


// Read only region start
class UserMainCode
{

    public class Result
    {
        public final int output1;
        public final int output2;

        public Result(int out1, int out2)
        {
            output1 = out1;
            output2 = out2;
        }
    }

    public Result decreasingSeq(int[] input1, int input2)
    {
        // Read only region end
        //Write code here...
        int no_of_seq = 0;
        int long_seq = 0, c = 1;
        for (int i = 1; i < input2; i++)
        {
            if (input1[i] < input1[i - 1])
            {
                c++;
            }
            else
            {
                if (c > long_seq && c != 1)
                {
                    long_seq = c;
                }
                if (c > 1)
                {
                    no_of_seq++;
                }
                c = 1;
            }
        }
        if (c > long_seq && c != 1)
        {
            long_seq = c;
        }
        if (c > 1)
        {
            no_of_seq++;
        }
        Result r = new Result(no_of_seq, long_seq);

        return r;
    }
}

