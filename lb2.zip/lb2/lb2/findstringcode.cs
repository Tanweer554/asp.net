﻿using System;
using System.Collections.Generic;

//Read only region start
public class UserMainCode
{
    public int findStringCode(string input1)
    {
        //Read only region end
        //Write code here

        int r = 0;
        string[] str2 = new string[10];
        string stri = input1.ToUpper();

        string[] str = stri.Split(' ');
        for (int i = 0; i < str.Length; i++)
        {
            char[] carr = str[i].ToCharArray();
            int sum = 0;
            for (int j = 0; j < carr.Length / 2; j++)
            {

                sum = sum + Math.Abs(GetValue(carr[j]) - GetValue(carr[carr.Length - 1 - j]));
            }
            if ((carr.Length % 2) != 0)
            {
                sum = sum + GetValue(carr[carr.Length / 2]);
            }
            str2[r++] = sum.ToString();
        }
        string st = "";
        for (int k = 0; k < r; k++)
        {
            st += str2[k];

        }
        return int.Parse(st);
    }

    public int GetValue(char c)
    {
        return (int)c - 64;
    }

}