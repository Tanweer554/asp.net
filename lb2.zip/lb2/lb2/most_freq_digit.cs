﻿using System;
using System.Collections.Generic;
//using System.Linq;

//Read only region start
public class UserMainCode
{
    public int mostFrequentlyOccurringDigit(int[] input1, int input2)
    {
        //Read only region end
        //Write code here
        int[] arr = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
        int max = 0, index = 0;
        for (int i = 0; i < input2; i++)
        {
            do
            {
                int rem = input1[i] % 10;
                arr[rem]++;
                input1[i] = input1[i] / 10;
            } while (input1[i] > 0);
        }
        for (int j = 0; j < arr.Length; j++)
        {
            if (arr[j] >= max)
            {
                max = arr[j];
                index = j;
            }
        }

        return index;
    }
}