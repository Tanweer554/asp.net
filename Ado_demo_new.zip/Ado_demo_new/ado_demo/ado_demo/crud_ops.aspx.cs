﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace ado_demo
{
    public partial class crud_ops : System.Web.UI.Page
    {
        EmployeeDAL emps = new EmployeeDAL();
        Employee e1 = new Employee();
        protected void Page_Load(object sender, EventArgs e)
        {
           /* SqlConnection con = new SqlConnection();
             con.ConnectionString = "Server=.;Initial Catalog=demodb;User ID=sa;Password=wipro@123";
             SqlCommand cmd = new SqlCommand();
             cmd.CommandText = "select * from employee";
             cmd.Connection = con;
             con.Open();
             SqlDataReader dr=cmd.ExecuteReader();
             GridView1.DataSource = dr;
             GridView1.DataBind();
             con.Close();*/

                   /* display for view all employees code*/
            GridView1.DataSource = emps.ViewAllEmployees();
            GridView1.DataBind();

        }

        protected void btninsert_Click(object sender, EventArgs e)
        {
            /* SqlConnection con = new SqlConnection();
             con.ConnectionString = "Server=.;Initial Catalog=demodb;User ID=sa;Password=wipro@123";
             SqlCommand cmd = new SqlCommand();
             cmd.CommandText = "Insert into employee(empname,age,[address],did) values(@en,@age,@address,@did)";
             cmd.Parameters.AddWithValue("@en", txtname.Text);
             cmd.Parameters.AddWithValue("@age", txtage.Text);
             cmd.Parameters.AddWithValue("@address", txtaddress.Text);
             cmd.Parameters.AddWithValue("@did", txtdid.Text);
             cmd.Connection = con;
             con.Open();
             int rowcount = cmd.ExecuteNonQuery();
             con.Close();
             if (rowcount == 1)
             {
                 Response.Write("Record Inserted");
             }*/
            e1.EmpName = txtname.Text;
            e1.Age = int.Parse(txtage.Text);
            e1.Address = txtaddress.Text;
            e1.did = int.Parse(txtdid.Text);
            int Empid=emps.AddEmployee(e1);
            if (Empid != 0)
            {
                Response.Write("Record inserted");
            }
        
        }

        protected void btndelete_Click(object sender, EventArgs e)
        {
            /* SqlConnection con = new SqlConnection();
             con.ConnectionString = "Server=.;Initial Catalog=demodb;User ID=sa;Password=wipro@123";
             SqlCommand cmd = new SqlCommand();
             cmd.CommandText = "delete from employee where empid=@eid";
             cmd.Parameters.AddWithValue("@eid", txtid.Text);

             cmd.Connection = con;
             con.Open();
             int rowcount = cmd.ExecuteNonQuery();
             con.Close();
             if (rowcount == 1)
             {
                 Response.Write("Record Deleted");
             }*/
        
            bool isdeleted=emps.DeleteEmployee(int.Parse(txtid.Text));
            if (isdeleted)
            {
                Response.Write("Record Deleted!!");
            }
            else
            {
                Response.Write("Record not found");
            }
        }

        protected void btnupdate_Click(object sender, EventArgs e)
        {
            /*  SqlConnection con = new SqlConnection();
               con.ConnectionString = "Server=.;Initial Catalog=demodb;User ID=sa;Password=wipro@123";
               SqlCommand cmd = new SqlCommand();
               cmd.CommandText = "update employee set  empname=@en,Age=@age,address=@address, did=@did where empid=@eid";
               cmd.Parameters.AddWithValue("@eid", txtid.Text);
               cmd.Parameters.AddWithValue("@en", txtname.Text);
               cmd.Parameters.AddWithValue("@age", txtage.Text);
               cmd.Parameters.AddWithValue("@address", txtaddress.Text);
               cmd.Parameters.AddWithValue("@did", txtdid.Text);

               cmd.Connection = con;
               con.Open();
               int rowcount = cmd.ExecuteNonQuery();
               con.Close();
               if (rowcount == 1)
               {
                   Response.Write("Record Updated");
               }*/
            e1.Empid = int.Parse(txtid.Text);
            e1.EmpName = txtname.Text;
            e1.Age = int.Parse(txtage.Text);
            e1.Address = txtaddress.Text;
            e1.did = int.Parse(txtdid.Text);
            bool isupdated=emps.UpdateEmployee(e1);
            if (isupdated)
            {
                Response.Write("record updated");
            }
            else
            {
                Response.Write("record doesnt exits");
            }
        }

        protected void btnsearch_Click(object sender, EventArgs e)
        {

            /*    SqlConnection con = new SqlConnection();
                con.ConnectionString = "Server=.;Initial Catalog=demodb;User ID=sa;Password=wipro@123";
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "select * from employee where empid=@id";

                cmd.Parameters.AddWithValue("@id", txtid.Text);

                cmd.Connection = con;
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dr.Read();

                    txtname.Text = dr["empname"].ToString();
                    txtage.Text = dr["age"].ToString();
                    txtaddress.Text = dr["address"].ToString();
                    txtdid.Text = dr["did"].ToString();


                }
                else
                {
                    Response.Write("No records found");
                }
                con.Close();*/
            
          Employee empl=emps.SearchEmployee(int.Parse(txtid.Text));
            if(empl!=null)
            {
                txtname.Text = empl.EmpName;
                txtage.Text = empl.Age.ToString();
                txtaddress.Text = empl.Address;
                txtdid.Text = empl.did.ToString();
            }
            else
            {
                Response.Write("Record not found");
            }
      
        }
    }
}