﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace ado_demo
{
    public class EmployeeDAL
    {
       // Employee e = new Employee();
        public List<Employee> ViewAllEmployees()
        {
            List<Employee> emplist = new List<Employee>();
           
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Server=.;Initial Catalog=demodb;User ID=sa;Password=wipro@123";
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "select * from employee";
            cmd.Connection = con;
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    Employee e = new Employee();

                    e.Empid = int.Parse(dr["empid"].ToString());
                    e.EmpName=dr["empname"].ToString();
                    e.Age = int.Parse(dr["age"].ToString());
                    e.Address = dr["address"].ToString();
                    e.did = int.Parse(dr["did"].ToString());
                    emplist.Add(e);
                   
                }
            }
            con.Close();
            return emplist;
        }
        public int AddEmployee(Employee emp)
        {
            int rtype=0;
            if (emp != null) {
                SqlConnection con = new SqlConnection();
                con.ConnectionString = "Server=.;Initial Catalog=demodb;User ID=sa;Password=wipro@123";
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "Insert into employee(empname,age,[address],did) values(@en,@age,@address,@did);select scope_identity()";
                cmd.Parameters.AddWithValue("@en", emp.EmpName);
                cmd.Parameters.AddWithValue("@age", emp.Age);
                cmd.Parameters.AddWithValue("@address", emp.Address);
                cmd.Parameters.AddWithValue("@did", emp.did);
                cmd.Connection = con;
                con.Open();
                int Empid = int.Parse(cmd.ExecuteScalar().ToString());
                con.Close();
                rtype = Empid;
            }

            return rtype;
           

        }
        public bool UpdateEmployee(Employee emp)
        {
          
            bool Isupdated = false;
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Server=.;Initial Catalog=demodb;User ID=sa;Password=wipro@123";
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "update employee set  empname=@en,Age=@age,address=@address, did=@did where empid=@eid";
            cmd.Parameters.AddWithValue("@eid",emp.Empid);
            cmd.Parameters.AddWithValue("@en", emp.EmpName);
            cmd.Parameters.AddWithValue("@age", emp.Age);
            cmd.Parameters.AddWithValue("@address", emp.Address);
            cmd.Parameters.AddWithValue("@did", emp.did);

            cmd.Connection = con;
            con.Open();
            int rowcount = cmd.ExecuteNonQuery();
            con.Close();
            if (rowcount == 1)
            {
                Isupdated = true;
            }
            return Isupdated;
        }
        public bool DeleteEmployee(int empId)
        {
            Employee e = new Employee();
            bool IsDeleted = false;
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Server=.;Initial Catalog=demodb;User ID=sa;Password=wipro@123";
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "delete from employee where empid=@eid";
            cmd.Parameters.AddWithValue("@eid", empId);

            cmd.Connection = con;
            con.Open();
            int rowcount = cmd.ExecuteNonQuery();
            con.Close();
            if (rowcount == 1)
            {
                IsDeleted = true;
            }
            return IsDeleted;
        }
        public Employee SearchEmployee(int empId)
        {
            Employee e = new Employee();
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Server=.;Initial Catalog=demodb;User ID=sa;Password=wipro@123";
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "select * from employee where empid=@id";

            cmd.Parameters.AddWithValue("@id", empId);

            cmd.Connection = con;
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                dr.Read();

                e.EmpName = dr["empname"].ToString();
                e.Age = int.Parse(dr["age"].ToString());
                e.Address = dr["address"].ToString();
                e.did = int.Parse(dr["did"].ToString());


            }
            con.Close();
            return e;
        }

    }


    }
