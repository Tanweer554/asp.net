﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace webapp1
{
    public partial class signup_form : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Btn_signup(object sender, EventArgs e)
        {
            Response.Redirect("Login form.aspx");
        }

        protected void Btn_reset(object sender, EventArgs e)
        {
            txtfirstname.Text = "";
            txtlastname.Text = "";
            txtemail.Text = "";
            txtaddress.Text = "";
            txtage.Text = "";
            txtpassword.Text = "";
            txtconfirmpassword.Text = "";
        }
    }
}