﻿using System;
//using System.Text;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace webapp1
{
    public partial class Login_form : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

     
        protected void Btn_login(object sender, EventArgs e)
        {
            if(txtusername.Text=="admin" && txtpassword.Text== "wipro@123")
            {
                Response.Redirect("home.aspx");
            }
            else
            {
                laberror.Visible = true;
            }
        }

      

        protected void Btn_signup(object sender, EventArgs e)
        {
            Response.Redirect("signup form.aspx");
        }
    }
}